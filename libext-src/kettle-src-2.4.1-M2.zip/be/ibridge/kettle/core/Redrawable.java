package be.ibridge.kettle.core;

public interface Redrawable
{
    public void redraw();
}
