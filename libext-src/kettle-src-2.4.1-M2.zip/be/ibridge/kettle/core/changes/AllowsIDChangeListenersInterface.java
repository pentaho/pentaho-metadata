package be.ibridge.kettle.core.changes;

public interface AllowsIDChangeListenersInterface
{
    public void addIDChangedListener(IDChangedListener listener);
}
