package be.ibridge.kettle.core;

public interface GUISizeInterface
{
    public int getWidth();
    public int getHeight();
    public void setWidth(int width);
    public void setHeight(int height);
}
