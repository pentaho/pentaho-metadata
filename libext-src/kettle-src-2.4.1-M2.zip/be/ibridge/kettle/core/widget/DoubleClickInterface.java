package be.ibridge.kettle.core.widget;

import org.eclipse.swt.widgets.TreeItem;

public interface DoubleClickInterface
{
    public void action(TreeItem treeItem);
}
