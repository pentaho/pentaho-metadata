package be.ibridge.kettle.core.widget;

public interface InsertTextInterface
{
    public void insertText(String text, int position);
}
