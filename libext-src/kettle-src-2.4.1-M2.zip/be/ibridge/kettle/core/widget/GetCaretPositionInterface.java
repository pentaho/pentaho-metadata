package be.ibridge.kettle.core.widget;

public interface GetCaretPositionInterface
{
    public int getCaretPosition();
}
