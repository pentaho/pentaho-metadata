package be.ibridge.kettle.core;

public class SharedObjectBase
{
    private boolean shared;
        
    public boolean isShared()
    {
        return shared;
    }

    public void setShared(boolean shared)
    {
        this.shared = shared;
    }
}
