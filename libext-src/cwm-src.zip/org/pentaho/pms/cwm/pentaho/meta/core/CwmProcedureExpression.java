package org.pentaho.pms.cwm.pentaho.meta.core;

/**
 * ProcedureExpression object instance interface.
 * In the metamodel ProcedureExpression defines a statement which will result 
 * in a change to the values of its environment when it is evaluated.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmProcedureExpression extends org.pentaho.pms.cwm.pentaho.meta.core.CwmExpression {
}
