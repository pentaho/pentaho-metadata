package org.pentaho.pms.cwm.pentaho.meta.olap;

/**
 * CubeOwnsCubeRegions association proxy interface.
 * A Cube may own any number of CubeRegions.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CubeOwnsCubeRegions extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param cubeRegion Value of the first association end.
     * @param cube Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(org.pentaho.pms.cwm.pentaho.meta.olap.CwmCubeRegion cubeRegion, org.pentaho.pms.cwm.pentaho.meta.olap.CwmCube cube);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param cube Required value of the second association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getCubeRegion(org.pentaho.pms.cwm.pentaho.meta.olap.CwmCube cube);
    /**
     * Queries the instance object that is related to a particular instance object 
     * by a link in the current associations link set.
     * @param cubeRegion Required value of the first association end.
     * @return Related object or <code>null</code> if none exists.
     */
    public org.pentaho.pms.cwm.pentaho.meta.olap.CwmCube getCube(org.pentaho.pms.cwm.pentaho.meta.olap.CwmCubeRegion cubeRegion);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param cubeRegion Value of the first association end.
     * @param cube Value of the second association end.
     */
    public boolean add(org.pentaho.pms.cwm.pentaho.meta.olap.CwmCubeRegion cubeRegion, org.pentaho.pms.cwm.pentaho.meta.olap.CwmCube cube);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param cubeRegion Value of the first association end.
     * @param cube Value of the second association end.
     */
    public boolean remove(org.pentaho.pms.cwm.pentaho.meta.olap.CwmCubeRegion cubeRegion, org.pentaho.pms.cwm.pentaho.meta.olap.CwmCube cube);
}
