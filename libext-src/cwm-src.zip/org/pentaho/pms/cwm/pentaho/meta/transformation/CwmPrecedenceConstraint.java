package org.pentaho.pms.cwm.pentaho.meta.transformation;

/**
 * PrecedenceConstraint object instance interface.
 * This is used to define order-of-execution constraint among TransformationSteps. 
 * It may be used independent of or in conjunction with StepPrecedence.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmPrecedenceConstraint extends org.pentaho.pms.cwm.pentaho.meta.core.CwmConstraint {
}
