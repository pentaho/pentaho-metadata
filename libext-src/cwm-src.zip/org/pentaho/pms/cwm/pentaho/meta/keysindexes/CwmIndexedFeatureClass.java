package org.pentaho.pms.cwm.pentaho.meta.keysindexes;

/**
 * IndexedFeature class proxy interface.
 * Instances of the IndexedFeature class map StructuralFeature instances of 
 * the spanned Class instance to the Index instances that employ them as (part 
 * of) their key. Attributes of IndexedFeature instances indicate how specific 
 * StructuralFeature instance are used in Index keys.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmIndexedFeatureClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmIndexedFeature createCwmIndexedFeature();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param isAscending The isAscending attribute is true if the feature is 
     * sorted in ascending order and false, if descending order.
     * @return The created instance object.
     */
    public CwmIndexedFeature createCwmIndexedFeature(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, java.lang.Boolean isAscending);
}
