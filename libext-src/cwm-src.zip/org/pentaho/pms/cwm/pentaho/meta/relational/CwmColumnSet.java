package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * ColumnSet object instance interface.
 * A set of columns, representing either the result of a query, a view or 
 * a physical table.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmColumnSet extends org.pentaho.pms.cwm.pentaho.meta.core.CwmClass {
}
