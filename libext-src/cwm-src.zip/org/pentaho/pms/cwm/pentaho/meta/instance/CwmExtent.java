package org.pentaho.pms.cwm.pentaho.meta.instance;

/**
 * Extent object instance interface.
 * Each instance of Extent owns a collection of instances and is used to link 
 * such collections to their structural and behavioral definitions in CWM 
 * Resource packages. Because Extent is a subclass of package, it owns member 
 * instances via the
 * ElementOwnership associaton.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmExtent extends org.pentaho.pms.cwm.pentaho.meta.core.CwmPackage {
}
