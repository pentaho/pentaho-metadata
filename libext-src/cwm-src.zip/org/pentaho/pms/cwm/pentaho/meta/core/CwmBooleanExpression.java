package org.pentaho.pms.cwm.pentaho.meta.core;

/**
 * BooleanExpression object instance interface.
 * In the metamodel BooleanExpression defines a statement which will evaluate 
 * to an instance of Boolean when it is evaluated.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmBooleanExpression extends org.pentaho.pms.cwm.pentaho.meta.core.CwmExpression {
}
