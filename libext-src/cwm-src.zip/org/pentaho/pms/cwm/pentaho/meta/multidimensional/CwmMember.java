package org.pentaho.pms.cwm.pentaho.meta.multidimensional;

/**
 * Member object instance interface.
 * Member represents a member of a Dimension.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmMember extends org.pentaho.pms.cwm.pentaho.meta.instance.CwmObject {
}
