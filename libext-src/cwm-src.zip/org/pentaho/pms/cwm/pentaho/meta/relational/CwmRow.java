package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * Row object instance interface.
 * An instance of a ColumnSet.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmRow extends org.pentaho.pms.cwm.pentaho.meta.instance.CwmObject {
}
