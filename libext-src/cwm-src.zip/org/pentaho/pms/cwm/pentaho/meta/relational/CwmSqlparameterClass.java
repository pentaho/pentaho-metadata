package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * SQLParameter class proxy interface.
 * Parameters of stored procedures.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmSqlparameterClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmSqlparameter createCwmSqlparameter();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param defaultValue An Expression whose evaluation yields a value to be 
     * used when no argument is supplied for the Parameter.
     * @param kind Specifies what kind of a Parameter is required.
     * @return The created instance object.
     */
    public CwmSqlparameter createCwmSqlparameter(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, org.pentaho.pms.cwm.pentaho.meta.core.CwmExpression defaultValue, org.pentaho.pms.cwm.pentaho.meta.behavioral.ParameterDirectionKind kind);
}
