package org.pentaho.pms.cwm.pentaho.meta.olap;

/**
 * Hierarchy class proxy interface.
 * A Hierarchy is an organizational structure that imposes a parent/child 
 * ordering on the members of the Dimension, usually to define either a navigational 
 * or consolidation/computational paths through the Dimension (i.e., a value 
 * associated with a child member is aggregated into one or more parents). 
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmHierarchyClass extends javax.jmi.reflect.RefClass {
}
