package org.pentaho.pms.cwm.pentaho.meta.instance;

/**
 * Slot class proxy interface.
 * A slot is a named location in an Object instance that holds the current 
 * value of the StructuralFeature associated with the Slot instance. Normally, 
 * the StructuralFeature associated with the slot will be either an Attribute 
 * instance or an AssociationEnd instance. Slots are owned by Objects; DataValues 
 * do not have slots.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmSlotClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmSlot createCwmSlot();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @return The created instance object.
     */
    public CwmSlot createCwmSlot(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility);
}
