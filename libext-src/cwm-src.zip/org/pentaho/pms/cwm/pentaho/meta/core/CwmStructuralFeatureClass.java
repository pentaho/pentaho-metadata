package org.pentaho.pms.cwm.pentaho.meta.core;

/**
 * StructuralFeature class proxy interface.
 * A structural feature refers to a static feature of a model element.
 * In the metamodel, a StructuralFeature declares a structural aspect of a 
 * Classifier that is typed, such as an attribute. For example, it specifies the mu
 * ltiplicity and changeability of the StructuralFeature. StructuralFeature is an a
 * bstract metaclass.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmStructuralFeatureClass extends javax.jmi.reflect.RefClass {
}
