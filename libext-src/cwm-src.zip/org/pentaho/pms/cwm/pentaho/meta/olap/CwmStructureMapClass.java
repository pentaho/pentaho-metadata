package org.pentaho.pms.cwm.pentaho.meta.olap;

/**
 * StructureMap class proxy interface.
 * StructureMap is a subclass of TransformationMap that maps Dimension attributes 
 * to their physical data sources.
 * (Note: Multiple StructureMaps may be grouped together into single, cohesive uni
 * t via TransformationTask.)
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmStructureMapClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmStructureMap createCwmStructureMap();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param function Any code or script for the Transformation.
     * @param functionDescription A short description for any code or script performed 
     * by the Transformation.
     * @param isPrimary This Transformation is the primary transformation for 
     * the associated TransformationTask.
     * @return The created instance object.
     */
    public CwmStructureMap createCwmStructureMap(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, org.pentaho.pms.cwm.pentaho.meta.core.CwmProcedureExpression function, java.lang.String functionDescription, boolean isPrimary);
}
