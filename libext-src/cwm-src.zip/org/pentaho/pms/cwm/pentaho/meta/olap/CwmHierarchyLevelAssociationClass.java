package org.pentaho.pms.cwm.pentaho.meta.olap;

/**
 * HierarchyLevelAssociation class proxy interface.
 * HierarchyLevelAssociation is a class that orders Levels within a LevelBasedHierarchy, 
 * and provides a means of mapping Level/Hierarchy-oriented  Dimension attributes 
 * to one or more physical deployments.
 * The relative ordering of DimensionDeployment classes optionally implies a desired orde
 * r of selection of DimensionDeployments, based on implementation-specific consid
 * erations (e.g., optimized access of aggregate data).
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmHierarchyLevelAssociationClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmHierarchyLevelAssociation createCwmHierarchyLevelAssociation();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param isAbstract An abstract Classifier is not instantiable.
     * @return The created instance object.
     */
    public CwmHierarchyLevelAssociation createCwmHierarchyLevelAssociation(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, boolean isAbstract);
}
