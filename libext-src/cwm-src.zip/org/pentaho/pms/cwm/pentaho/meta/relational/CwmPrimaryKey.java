package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * PrimaryKey object instance interface.
 * There is only one UniqueConstraint of type PrimaryKey per Table. It is 
 * implemented specifically by each RDBMS.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmPrimaryKey extends org.pentaho.pms.cwm.pentaho.meta.relational.CwmUniqueConstraint {
}
