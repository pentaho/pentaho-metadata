package org.pentaho.pms.cwm.pentaho.meta.transformation;

/**
 * TransformationMap object instance interface.
 * This represents a specialized Transformation which consists of a group 
 * of ClassifierMaps.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmTransformationMap extends org.pentaho.pms.cwm.pentaho.meta.transformation.CwmTransformation {
    /**
     * Returns the value of reference classifierMap.
     * @return Value of reference classifierMap. Element type: {@link org.pentaho.pms.cwm.pentaho.meta.core.CwmModelElement}
     */
    public java.util.Collection/*<org.pentaho.pms.cwm.pentaho.meta.core.CwmModelElement>*/ getClassifierMap();
}
