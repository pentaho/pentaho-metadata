package org.pentaho.pms.cwm.pentaho.meta.behavioral;

/**
 * Interface class proxy interface.
 * Interface is a named set of operations that specify the behavior of an 
 * element.
 * In the metamodel, an Interface contains a set of Operations that togeth
 * er define a service offered by a Classifier realizing the Interface. A Clas
 * sifier may offer several services, which means that it may realize several 
 * Interfaces, and several Classifiers may realize the same Interface.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmInterfaceClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmInterface createCwmInterface();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param isAbstract An abstract Classifier is not instantiable.
     * @return The created instance object.
     */
    public CwmInterface createCwmInterface(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, boolean isAbstract);
}
