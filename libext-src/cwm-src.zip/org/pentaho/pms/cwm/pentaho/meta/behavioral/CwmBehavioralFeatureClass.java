package org.pentaho.pms.cwm.pentaho.meta.behavioral;

/**
 * BehavioralFeature class proxy interface.
 * A behavioral feature refers to a dynamic feature of a model element, such 
 * as an operation or method. In the metamodel, BehavioralFeature specifies 
 * a behavioral aspect of a Classifier. All different kinds of behavioral 
 * aspects of a Classifier, such as Operation and Method, are subclasses of 
 * BehavioralFeature.
 * BehavioralFeature is an abstract metaclass.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmBehavioralFeatureClass extends javax.jmi.reflect.RefClass {
}
