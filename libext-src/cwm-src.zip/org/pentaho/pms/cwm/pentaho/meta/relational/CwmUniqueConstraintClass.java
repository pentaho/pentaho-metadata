package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * UniqueConstraint class proxy interface.
 * A condition to define uniqueness of rows in a table. An example of UniqueConstraint 
 * is a primary key
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmUniqueConstraintClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmUniqueConstraint createCwmUniqueConstraint();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param deferrability Indicates if the validity of the UniqueConstraint 
     * is to be tested at each statement or at the end of a transaction.
     * @return The created instance object.
     */
    public CwmUniqueConstraint createCwmUniqueConstraint(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, org.pentaho.pms.cwm.pentaho.meta.relational.enumerations.DeferrabilityType deferrability);
}
