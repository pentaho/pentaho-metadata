package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * NamedColumnSet class proxy interface.
 * A catalogued set of columns, which may be Table or View.
 * Note for typed tables: It is assumed that the typed table will own a set 
 * of columns conforming to the type they are OF. This set of columns allows the ma
 * nipulation of the table by products which ignore this [SQL] extension. I
 * t also allows the columns of type REF, to be copied to a column with a S
 * COPE reference.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmNamedColumnSetClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmNamedColumnSet createCwmNamedColumnSet();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param isAbstract An abstract Classifier is not instantiable.
     * @return The created instance object.
     */
    public CwmNamedColumnSet createCwmNamedColumnSet(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, boolean isAbstract);
}
