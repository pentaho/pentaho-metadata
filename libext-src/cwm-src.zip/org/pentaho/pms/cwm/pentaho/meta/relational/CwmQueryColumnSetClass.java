package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * QueryColumnSet class proxy interface.
 * The result set of a query.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmQueryColumnSetClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public CwmQueryColumnSet createCwmQueryColumnSet();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name An identifier for the ModelElement within its containing Namespace.
     * @param visibility Specifies extent of the visibility of the ModelElement 
     * within its owning Namespace.
     * @param isAbstract An abstract Classifier is not instantiable.
     * @param query The query expression generating this result. The language 
     * attribute of the expression should generally begin with "SQL"
     * @return The created instance object.
     */
    public CwmQueryColumnSet createCwmQueryColumnSet(java.lang.String name, org.pentaho.pms.cwm.pentaho.meta.core.VisibilityKind visibility, boolean isAbstract, org.pentaho.pms.cwm.pentaho.meta.datatypes.CwmQueryExpression query);
}
