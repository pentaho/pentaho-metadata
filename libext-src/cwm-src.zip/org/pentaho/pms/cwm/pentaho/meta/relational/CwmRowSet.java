package org.pentaho.pms.cwm.pentaho.meta.relational;

/**
 * RowSet object instance interface.
 * Each instance of RowSet owns a collection of Row instances. The inherited 
 * association between Namespace (a superclass of Package) and ModelElement 
 * is used to contain Instances.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmRowSet extends org.pentaho.pms.cwm.pentaho.meta.instance.CwmExtent {
}
