package org.pentaho.pms.cwm.pentaho.meta.core;

/**
 * Feature class proxy interface.
 * A feature is a property, like attribute or operation, which is encapsulated 
 * within a Classifier.
 * In the metamodel, a Feature declares a structural or behavioral characterist
 * ic of an instance of a Classifier or of the Classifier itself. Feature i
 * s an abstract metaclass.
 *  
 * <p><em><strong>Note:</strong> This type should not be subclassed or implemented 
 * by clients. It is generated from a MOF metamodel and automatically implemented 
 * by MDR (see <a href="http://mdr.netbeans.org/">mdr.netbeans.org</a>).</em></p>
 */
public interface CwmFeatureClass extends javax.jmi.reflect.RefClass {
}
