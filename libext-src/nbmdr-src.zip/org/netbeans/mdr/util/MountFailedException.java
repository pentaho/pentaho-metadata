/*
 * The contents of this file are subject to the terms of the Common Development
 * and Distribution License (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at http://www.netbeans.org/cddl.html
 * or http://www.netbeans.org/cddl.txt.
 *
 * When distributing Covered Code, include this CDDL Header Notice in each file
 * and include the License file at http://www.netbeans.org/cddl.txt.
 * If applicable, add the following below the CDDL Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.mdr.util;

/**
 *
 * @author  Tomas Zezula
 */
public class MountFailedException extends java.lang.Exception {

    private Exception rootCase;

    /**
     * Creates a new instance of <code>MountFailedException</code> without detail message.
     */
    public MountFailedException () {
    }


    /**
     * Constructs an instance of <code>MountFailedException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public MountFailedException(String msg) {
        this (msg, null);
    }
    
    /**
     * Constructs an instance of <code>MountFailedException</code> with the specified detail message and root case exception.
     * @param msg the detail message.
     * @param rootCase the root case exception
     */
    public MountFailedException (String message, Exception rootCase) {
        super (message);
        this.rootCase = rootCase;
    }
    
    /**
     *  Returns the root case exception.
     *  @return Exception the root case exception
     */
    public Exception getRootCase () {
        return this.rootCase;
    }
}
