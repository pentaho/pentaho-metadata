/*
 * The contents of this file are subject to the terms of the Common Development
 * and Distribution License (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at http://www.netbeans.org/cddl.html
 * or http://www.netbeans.org/cddl.txt.
 *
 * When distributing Covered Code, include this CDDL Header Notice in each file
 * and include the License file at http://www.netbeans.org/cddl.txt.
 * If applicable, add the following below the CDDL Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.util;

/**
 *
 * @author Marek Sedliak, Daniel Prusa
 * @version
 */
public interface XmiConstants {

    //General constants
    public static final String NOT_RESOLVED = "Not resolved";
    public static final String XMI_CURRENT_VERSION = "1.1";
    public static final String XMI_OLD_VERSION = "1.0";
    public static final String MOF_CURRENT_VERSION = "1.4";
    public static final String MOF_METAMODEL = "MOF";
    public static final String NS_SEPARATOR = ":";
    public static final String DOT_SEPARATOR = ".";
    public static final String SPACE = " ";
    public static final String TEXT_NODE_NAME = "#text";
    public static final String COMMENT_NODE_NAME = "#comment";
    public static final String CONTAINS_REFERENCE = "contents";
    public static final String NAMESPACE_CONTENTS = "Namespace.contents";
    public static final String XMI_PREFIX = "XMI.";
    public static final String IS_ABSTRACT = "isAbstract";
    public static final String NONE = "none";
    public static final String FALSE = "false";
    public static final String TRUE = "true";
    public static final String WARNING = "WARNING !!! ";
    public static final String XMI_ID_PREFIX = "a";
    public static final String INDENT = "     ";

    //Basic elements
    public static final String XMI_ROOT = "XMI";
    public static final String XMI_HEADER = "XMI.header";
    public static final String XMI_CONTENT = "XMI.content";
    public static final String XMI_DIFFERENCE = "XMI.difference";
    public static final String XMI_DELETE = "XMI.delete";
    public static final String XMI_ADD = "XMI.add";
    public static final String XMI_REPLACE = "XMI.replace";
    public static final String XMI_EXTENSIONS = "XMI.extensions";
    
    //Sub elements for XMI_HEADER
    public static final String XMI_DOCUMENTATION = "XMI.documentation";
    public static final String XMI_MODEL = "XMI.model";
    public static final String XMI_METAMODEL = "XMI.metamodel";
    public static final String XMI_METAMETAMODEL = "XMI.metametamodel";
    public static final String XMI_IMPORT = "XMI.import";
    
    //Attributes
    public static final String XMI_ID = "xmi.id";
    public static final String XMI_UUID = "xmi.uuid";
    public static final String XMI_LABEL = "xmi.label";
    public static final String XMI_IDREF = "xmi.idref";
    public static final String XMI_HREF = "href";
    public static final String XMI_POSITION = "xmi.position";
    public static final String XMI_IDREF_FLAG = " ###idref###";
    public static final String XMI_VersionAtt = "xmi.version";
    public static final String XMI_NameAtt = "xmi.name";
    public static final String XMI_VALUE = "xmi.value";
    public static final String XMI_TYPE = "xmi.type";
    public static final String TYPE_ATTRIBUTE = "type";
    public static final String NAME_ATTRIBUTE = "name";
    
    
    //DataTypes
    public static final String DATA_TYPE = "DataType";
    public static final String DATA_TYPE_TYPE_CODE = "DataType.typeCode";
    public static final String TYPE_CODE = "typeCode";
    public static final String XMI_CORBA_TYPE_CODE = "XMI.CorbaTypeCode";
    public static final String XMI_ANY_TYPE = "XMI.any";
    public static final String XMI_FIELD = "XMI.field";


    public static final String BOOLEAN_TYPE = "Boolean";
    public static final String BYTE_TYPE ="Byte";
    public static final String CHARACTER_TYPE = "Character";
    public static final String CHARACTER8_TYPE ="Character8";
    public static final String DATE_TYPE = "Date";
    public static final String DOUBLE_TYPE = "Double";
    public static final String FLOAT_TYPE ="Float";
    public static final String INTEGER_TYPE ="Integer";
    public static final String UNSIGNED_INTEGER_TYPE = "Unsigned Integer";
    public static final String LONG_TYPE ="Long";
    public static final String UNSIGNED_LONG_TYPE = "Unsigned Long";
    public static final String SHORT_TYPE = "Short";
    public static final String UNSIGNED_SHORT_TYPE = "Unsigned Short";
    public static final String STRING_TYPE = "String";
    public static final String STRING8_TYPE = "String8";
    public static final String OBJECT_TYPE = "Object";

    //Corba types
    public static final String XMICorbaTcField = "XMI.CorbaTcField";
    public static final String XMI_TCNAME = "xmi.tcName";
    public static final String XMI_CorbaTcEnumLabel = "XMI.CorbaTcEnumLabel";

    public static final String XMICorbaTcStruct = "XMI.CorbaTcStruct";
    public static final String XMICorbaTcEnum = "XMI.CorbaTcEnum";
    public static final String XMICorbaTcUnion = "XMI.CorbaTcUnion";
    public static final String XMICorbaTcObjRef = "XMI.CorbaTcObjRef";
    public static final String XMICorbaTcArray = "XMI.CorbaTcArray";
    public static final String XMICorbaTcAlias = "XMI.CorbaTcAlias";
    public static final String XMICorbaTcSequence = "XMI.CorbaTcSequence";
    public static final String XMICorbaTcAny = "XMI.CorbaTcAny";
    
    public static final String XMICorbaTcExcept = "XMI.CorbaTcExcept";
    public static final String XMICorbaTcTypeCode = "XMI.CorbaTcTypeCode";
    public static final String XMICorbaTcPrincipal = "XMI.CorbaTcPrincipal";
    public static final String XMICorbaTcNull = "XMI.CorbaTcNull";
    public static final String XMICorbaTcVoid = "XMI.CorbaTcVoid";
    
    public static final String XMICorbaTcShort = "XMI.CorbaTcShort";
    public static final String XMICorbaTcLong = "XMI.CorbaTcLong";
    public static final String XMICorbaTcUShort = "XMI.CorbaTcUShort";
    public static final String XMICorbaTcULong = "XMI.CorbaTcULong";
    public static final String XMICorbaTcFloat = "XMI.CorbaTcFloat";
    public static final String XMICorbaTcDouble = "XMI.CorbaTcDouble";
    public static final String XMICorbaTcBoolean = "XMI.CorbaTcBoolean";
    public static final String XMICorbaTcChar = "XMI.CorbaTcChar";
    public static final String XMICorbaTcWChar = "XMI.CorbaTcWChar";
    public static final String XMICorbaTcOctet = "XMI.CorbaTcOctet";
    public static final String XMICorbaTcString = "XMI.CorbaTcString";
    public static final String XMICorbaTcWString = "XMI.CorbaTcWString";
    public static final String XMICorbaTcLongLong = "XMI.CorbaTcLongLong";
    public static final String XMICorbaTcULongLong = "XMI.CorbaTcULongLong";
    public static final String XMICorbaTcLongDouble = "XMI.CorbaTcLongDouble";

    //Packages
    public static final String PRIMITIVE_TYPES_PACKAGE = "PrimitiveTypes";

    //Corba transversing consts
    public static final String STRUCTURE_TYPE = "StructureType";
    public static final String ENUMERATION_TYPE = "EnumerationType";
    public static final String ATTRIBUTE_TYPE = "Attribute";
    public static final String PRIMITIVE_TYPE = "PrimitiveType";
    public static final String VISIBILITY_KIND = "VisibilityKind";
    public static final String SCOPE_KIND = "ScopeKind";
    public static final String MULTIPLICITY_TYPE = "MultiplicityType";
    public static final String CONSTRAINT = "Constraint";
}
